
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class StatistikPage extends StatelessWidget {
  const StatistikPage({super.key});

  // Data demonstrasi, bukan data pengajuan aktual.
  static const int totalPengajuan = 120;
  static const int diproses = 35;
  static const int selesai = 70;
  static const int ditolak = 15;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Statistik Pengajuan'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Ringkasan Pengajuan',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),

            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.7,
              children: const [
                _KartuStatistik(
                  judul: 'Total Pengajuan',
                  jumlah: totalPengajuan,
                  warna: Colors.blue,
                  ikon: Icons.assignment,
                ),
                _KartuStatistik(
                  judul: 'Diproses',
                  jumlah: diproses,
                  warna: Colors.orange,
                  ikon: Icons.pending_actions,
                ),
                _KartuStatistik(
                  judul: 'Selesai',
                  jumlah: selesai,
                  warna: Colors.green,
                  ikon: Icons.check_circle_outline,
                ),
                _KartuStatistik(
                  judul: 'Ditolak',
                  jumlah: ditolak,
                  warna: Colors.red,
                  ikon: Icons.cancel_outlined,
                ),
              ],
            ),

            const SizedBox(height: 28),

            const Text(
              'Grafik Status Pengajuan',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Perbandingan jumlah pengajuan berdasarkan status.',
            ),
            const SizedBox(height: 24),

            SizedBox(
              height: 280,
              child: BarChart(
                BarChartData(
                  maxY: 140,
                  minY: 0,
                  alignment: BarChartAlignment.spaceAround,
                  gridData: const FlGridData(show: true),
                  borderData: FlBorderData(show: false),
                  barTouchData: BarTouchData(enabled: true),
                  titlesData: FlTitlesData(
                    topTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    rightTitles: const AxisTitles(
                      sideTitles: SideTitles(showTitles: false),
                    ),
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 38,
                        interval: 20,
                        getTitlesWidget: (value, meta) {
                          return Text(
                            value.toInt().toString(),
                            style: const TextStyle(fontSize: 11),
                          );
                        },
                      ),
                    ),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        reservedSize: 40,
                        getTitlesWidget: (value, meta) {
                          const labels = [
                            'Total',
                            'Proses',
                            'Selesai',
                            'Ditolak',
                          ];

                          final index = value.toInt();

                          if (index < 0 || index >= labels.length) {
                            return const SizedBox.shrink();
                          }

                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              labels[index],
                              style: const TextStyle(fontSize: 10),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  barGroups: [
                    _batang(0, totalPengajuan, Colors.blue),
                    _batang(1, diproses, Colors.orange),
                    _batang(2, selesai, Colors.green),
                    _batang(3, ditolak, Colors.red),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            const Text(
              'Keterangan',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            const _Legenda(
              warna: Colors.blue,
              teks: 'Total seluruh pengajuan',
            ),
            const _Legenda(
              warna: Colors.orange,
              teks: 'Pengajuan yang sedang diproses',
            ),
            const _Legenda(
              warna: Colors.green,
              teks: 'Pengajuan yang selesai',
            ),
            const _Legenda(
              warna: Colors.red,
              teks: 'Pengajuan yang ditolak',
            ),
          ],
        ),
      ),
    );
  }

  static BarChartGroupData _batang(
    int x,
    int jumlah,
    Color warna,
  ) {
    return BarChartGroupData(
      x: x,
      barRods: [
        BarChartRodData(
          toY: jumlah.toDouble(),
          color: warna,
          width: 28,
          borderRadius: const BorderRadius.vertical(
            top: Radius.circular(5),
          ),
        ),
      ],
    );
  }
}

class _KartuStatistik extends StatelessWidget {
  final String judul;
  final int jumlah;
  final Color warna;
  final IconData ikon;

  const _KartuStatistik({
    required this.judul,
    required this.jumlah,
    required this.warna,
    required this.ikon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(ikon, color: warna, size: 28),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    judul,
                    style: const TextStyle(fontSize: 11),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    jumlah.toString(),
                    style: TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                      color: warna,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Legenda extends StatelessWidget {
  final Color warna;
  final String teks;

  const _Legenda({
    required this.warna,
    required this.teks,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(
            width: 14,
            height: 14,
            decoration: BoxDecoration(
              color: warna,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(teks)),
        ],
      ),
    );
  }
}
